./run.sh /cbr/anand/ASR_Challenge/Data/Tamil/ASR/tamil_uniq_asr_dev.txt /cbr/anand/ASR_Challenge/Data/Tamil/ASR/tamil_uniq_asr_dev_cls.txt

./run.sh /cbr/anand/ASR_Challenge/Data/Telugu/ASR/telugu_uniq_asr_train.txt /cbr/anand/ASR_Challenge/Data/Telugu/ASR/telugu_uniq_asr_train_cls.txt
./run.sh /cbr/anand/ASR_Challenge/Data/Telugu/ASR/telugu_uniq_asr_dev.txt /cbr/anand/ASR_Challenge/Data/Telugu/ASR/telugu_uniq_asr_dev_cls.txt

./run.sh /cbr/anand/ASR_Challenge/Data/Marathi/TTS/marathi_uniq_tts.txt /cbr/anand/ASR_Challenge/Data/Marathi/TTS/marathi_uniq_tts_cls.txt
./run.sh /cbr/anand/ASR_Challenge/Data/Oriya/TTS/oriya_uniq_tts.txt /cbr/anand/ASR_Challenge/Data/Oriya/TTS/oriya_uniq_tts_cls.txt
./run.sh /cbr/anand/ASR_Challenge/Data/Tamil/TTS/tamil_uniq_tts.txt /cbr/anand/ASR_Challenge/Data/Tamil/TTS/tamil_uniq_tts_cls.txt
./run.sh /cbr/anand/ASR_Challenge/Data/Telugu/TTS/telugu_uniq_tts.txt /cbr/anand/ASR_Challenge/Data/Telugu/TTS/telugu_uniq_tts_cls.txt

